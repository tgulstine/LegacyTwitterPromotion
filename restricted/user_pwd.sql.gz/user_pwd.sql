CREATE TABLE user_pwd (
    name CHAR(30) NOT NULL,
    pass CHAR(32) NOT NULL,
    PRIMARY KEY (name)
)
